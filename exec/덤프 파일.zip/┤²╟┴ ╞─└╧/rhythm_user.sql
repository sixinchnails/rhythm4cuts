-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: i9b109.p.ssafy.io    Database: rhythm
-- ------------------------------------------------------
-- Server version	8.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `user_seq` int NOT NULL,
  `connection_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `create_date` datetime(6) DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_online` int DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nickname` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `play_count` int DEFAULT NULL,
  `point` int DEFAULT NULL,
  `refresh_token` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `resign_date` datetime(6) DEFAULT NULL,
  `score_sum` int DEFAULT NULL,
  `state` int DEFAULT NULL,
  `profile_image_seq` int DEFAULT NULL,
  PRIMARY KEY (`user_seq`),
  KEY `FKtn8feo4bxm7oaunq59dsstec1` (`profile_image_seq`),
  CONSTRAINT `FKtn8feo4bxm7oaunq59dsstec1` FOREIGN KEY (`profile_image_seq`) REFERENCES `profile_image` (`profile_image_seq`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (6,NULL,'2023-08-18 00:07:56.682306','ssafy@naver.com','M',0,'Han','ssafy','$2a$10$d8y/0PaLSxW85BumABOcxezk7JMc9t.RHyZFJnTAUChAEuJVbj7SC',0,100,NULL,NULL,7000,0,4),(7,NULL,'2023-08-18 00:07:56.816716','abc@gmail.com','F',0,'hyun','hyun','$2a$10$Cgg.jrXTpDNFm5ujyRCO0.kb6vhzIE.Rs8iQ2DxJJNN8FtMBoSFQO',0,0,NULL,NULL,0,0,1),(8,NULL,'2023-08-18 00:07:56.936540','acd4548@naver.com','M',1,'민국','민국','$2a$10$KlSreG62z.GR0jFESaF2GurcIXDF//BMJEXDDjdGqJ4P2GkFyo6Lu',0,0,NULL,NULL,0,0,1),(9,NULL,'2023-08-18 00:07:57.049796','a@naver.com','F',1,'강현','현','$2a$10$rcDIAa/csFPIHAeeLHSHt.V5RSG4g.RqdYulfHFva.cw1vLWI9Udq',0,1200,NULL,NULL,0,0,1),(10,NULL,'2023-08-18 00:07:57.164799','ab@naver.com','M',0,'홍유빈','홍유콩','$2a$10$0zxhVvVZfsdVHuYjIdE.JOBtbHD1ePJWhdRbL5.QbOqs9seN582yW',0,1000,NULL,NULL,0,0,2),(11,NULL,'2023-08-18 00:07:57.281228','b@naver.com','M',0,'최재용','최재드래곤','$2a$10$0qqe10RVrIIqY2CAXEKnSeK7blhgZwXrvMhlsUierv9meUbbc0b5S',0,800,NULL,NULL,0,0,3),(12,NULL,'2023-08-18 00:07:57.396617','bc@naver.com','F',1,'최한윤','최고다한윤','$2a$10$4ccq0UxbjG5G694Ork6BDO01T6hKJnz.kp0Mn1Tj17O4MMOjqnIBq',0,600,NULL,NULL,0,0,3),(13,NULL,'2023-08-18 00:07:57.516267','z@naver.com','F',1,'강현','현순','$2a$10$frQ2Bgp63qhtsQb23N5lDuw4/wxhHkaiQZsnvCN1GQdTD2JfKlkIi',0,1100,NULL,NULL,0,0,1);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-08-21 10:08:21
