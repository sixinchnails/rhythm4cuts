-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: i9b109.p.ssafy.io    Database: rhythm
-- ------------------------------------------------------
-- Server version	8.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `game_info`
--

DROP TABLE IF EXISTS `game_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_info` (
  `game_seq` int NOT NULL,
  `create_date` datetime(6) DEFAULT NULL,
  `has_image` bit(1) DEFAULT NULL,
  `head_count` int DEFAULT NULL,
  `is_secret` bit(1) DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `session_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `song_seq` int DEFAULT NULL,
  PRIMARY KEY (`game_seq`),
  KEY `FKkif1dvctficwdjm0ut05qom4y` (`song_seq`),
  CONSTRAINT `FKkif1dvctficwdjm0ut05qom4y` FOREIGN KEY (`song_seq`) REFERENCES `song` (`song_seq`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_info`
--

LOCK TABLES `game_info` WRITE;
/*!40000 ALTER TABLE `game_info` DISABLE KEYS */;
INSERT INTO `game_info` VALUES (123,'2023-08-18 00:12:25.610413',_binary '\0',0,_binary '\0','','WAIT','ses_TSh4Zx09FB','들어와',119),(135,'2023-08-18 00:20:15.466497',_binary '\0',0,_binary '\0','','WAIT','ses_JtlWn53GmZ','들어와줘요',115),(148,'2023-08-18 00:39:22.390928',_binary '\0',1,_binary '\0','','WAIT','ses_JO8LZJtjyQ','1',115),(158,'2023-08-18 00:45:07.745169',_binary '\0',0,_binary '\0','','WAIT','ses_IoYrG3WHkK','사랑',119),(165,'2023-08-18 00:55:26.115442',_binary '\0',0,_binary '\0','','WAIT','ses_V2zAu25Eza','t',117),(171,'2023-08-18 01:47:36.677418',_binary '\0',1,_binary '','123123','WAIT','ses_RS4PWjNBNU','보고싶다',117),(174,'2023-08-18 01:48:02.481845',_binary '\0',1,_binary '','123123','WAIT','ses_Hb2llcsJ1d','춤추면서 부르자잇',115),(177,'2023-08-18 01:48:28.429950',_binary '\0',1,_binary '','123123','WAIT','ses_RZocDGMLjf','해가뜨고지네yo',119),(180,'2023-08-18 01:49:01.615362',_binary '\0',1,_binary '','123123','WAIT','ses_MEw23vPx5m','사건일어나부러써',116),(183,'2023-08-18 01:49:56.064700',_binary '\0',1,_binary '','123','WAIT','ses_WPBbSwTTTE','무진 다들 보았쥬?',118),(188,'2023-08-18 02:55:24.101089',_binary '\0',-1,_binary '\0','','WAIT','ses_NgRomxTjWu','들어와줘잉',119),(197,'2023-08-18 02:59:18.494144',_binary '\0',0,_binary '\0','','WAIT','ses_VH0DKrtMrU','지금 방 만듬',119),(206,'2023-08-18 03:00:56.102135',_binary '\0',1,_binary '\0','','WAIT','ses_XLFUjXY0Z4','ㄷㄷ',119),(219,'2023-08-18 03:06:16.680252',_binary '\0',-1,_binary '\0','','WAIT','ses_Xb85S5PEMN','제발',119),(230,'2023-08-18 03:14:09.122592',_binary '\0',0,_binary '\0','','WAIT','ses_Pw2IqiB8ih','지금 방 만듬',119),(245,'2023-08-18 03:39:49.366642',_binary '\0',-1,_binary '\0','','WAIT','ses_ZtaD5Z9lUM','마이크 쳌 원투',119),(259,'2023-08-18 03:44:19.458365',_binary '\0',0,_binary '\0','','WAIT','ses_FpHYSU8T8F','제발 들어와줘잉~~',119),(280,'2023-08-18 08:22:26.321147',_binary '\0',1,_binary '\0','','WAIT','ses_ZCB3DCPHig','coach',119),(285,'2023-08-18 08:23:18.864024',_binary '\0',1,_binary '\0','','WAIT','ses_V1yJT37Tjd','coach',119),(400,'2023-08-19 17:46:14.098706',_binary '\0',4,_binary '\0','','WAIT','ses_Aiz08autLi','11',119);
/*!40000 ALTER TABLE `game_info` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-08-21 10:08:26
