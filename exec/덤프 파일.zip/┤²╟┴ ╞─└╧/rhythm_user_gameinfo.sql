-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: i9b109.p.ssafy.io    Database: rhythm
-- ------------------------------------------------------
-- Server version	8.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user_gameinfo`
--

DROP TABLE IF EXISTS `user_gameinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_gameinfo` (
  `user_gameinfo_seq` int NOT NULL,
  `game_order` int DEFAULT NULL,
  `game_rank` int DEFAULT NULL,
  `game_score` int DEFAULT NULL,
  `has_image` bit(1) DEFAULT NULL,
  `is_host` bit(1) DEFAULT NULL,
  `game_seq` int DEFAULT NULL,
  `user_seq` int DEFAULT NULL,
  PRIMARY KEY (`user_gameinfo_seq`),
  KEY `FKi9bwqmqagquyqn0cy965w9pw4` (`game_seq`),
  KEY `FKe8lq4hlxfa7lh0symynamks9o` (`user_seq`),
  CONSTRAINT `FKe8lq4hlxfa7lh0symynamks9o` FOREIGN KEY (`user_seq`) REFERENCES `user` (`user_seq`),
  CONSTRAINT `FKi9bwqmqagquyqn0cy965w9pw4` FOREIGN KEY (`game_seq`) REFERENCES `game_info` (`game_seq`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_gameinfo`
--

LOCK TABLES `user_gameinfo` WRITE;
/*!40000 ALTER TABLE `user_gameinfo` DISABLE KEYS */;
INSERT INTO `user_gameinfo` VALUES (124,1,NULL,0,_binary '\0',_binary '\0',123,10),(126,2,NULL,0,_binary '\0',_binary '\0',123,8),(128,3,NULL,0,_binary '\0',_binary '\0',123,6),(130,4,NULL,0,_binary '\0',_binary '\0',123,7),(136,1,NULL,0,_binary '\0',_binary '\0',135,10),(138,2,NULL,0,_binary '\0',_binary '\0',135,6),(140,3,NULL,0,_binary '\0',_binary '\0',135,8),(142,4,NULL,0,_binary '\0',_binary '\0',135,7),(149,1,NULL,0,_binary '\0',_binary '\0',148,8),(159,1,NULL,0,_binary '\0',_binary '\0',158,10),(161,2,NULL,0,_binary '\0',_binary '\0',158,6),(163,3,NULL,0,_binary '\0',_binary '\0',158,8),(166,1,NULL,0,_binary '\0',_binary '\0',165,6),(168,2,NULL,0,_binary '\0',_binary '\0',165,9),(172,1,NULL,0,_binary '\0',_binary '\0',171,6),(175,1,NULL,0,_binary '\0',_binary '\0',174,6),(178,1,NULL,0,_binary '\0',_binary '\0',177,6),(181,1,NULL,0,_binary '\0',_binary '\0',180,6),(184,1,NULL,0,_binary '\0',_binary '\0',183,6),(186,2,NULL,0,_binary '\0',_binary '\0',148,6),(189,1,NULL,0,_binary '\0',_binary '\0',188,6),(191,2,NULL,0,_binary '\0',_binary '\0',188,9),(193,3,NULL,0,_binary '\0',_binary '\0',188,7),(195,4,NULL,0,_binary '\0',_binary '\0',188,8),(198,1,NULL,0,_binary '\0',_binary '\0',197,6),(200,2,NULL,0,_binary '\0',_binary '\0',197,9),(202,3,NULL,0,_binary '\0',_binary '\0',197,7),(204,4,NULL,0,_binary '\0',_binary '\0',197,8),(207,1,NULL,0,_binary '\0',_binary '\0',206,6),(209,2,NULL,0,_binary '\0',_binary '\0',206,8),(211,3,NULL,0,_binary '\0',_binary '\0',206,7),(213,4,NULL,0,_binary '\0',_binary '\0',206,9),(220,1,NULL,0,_binary '\0',_binary '\0',219,6),(222,2,NULL,0,_binary '\0',_binary '\0',219,7),(224,3,NULL,0,_binary '\0',_binary '\0',219,8),(226,4,NULL,0,_binary '\0',_binary '\0',219,9),(231,1,NULL,0,_binary '\0',_binary '\0',230,6),(233,2,NULL,0,_binary '\0',_binary '\0',230,9),(235,3,NULL,0,_binary '\0',_binary '\0',230,7),(237,4,NULL,0,_binary '\0',_binary '\0',230,8),(246,1,NULL,0,_binary '\0',_binary '\0',245,9),(248,2,NULL,0,_binary '\0',_binary '\0',245,8),(250,3,NULL,0,_binary '\0',_binary '\0',245,7),(260,1,NULL,0,_binary '\0',_binary '\0',259,6),(262,2,NULL,0,_binary '\0',_binary '\0',259,8),(264,3,NULL,0,_binary '\0',_binary '\0',259,9),(281,1,NULL,0,_binary '\0',_binary '\0',280,6),(283,2,NULL,0,_binary '\0',_binary '\0',280,12),(286,1,NULL,0,_binary '\0',_binary '\0',285,6),(288,2,NULL,0,_binary '\0',_binary '\0',285,12),(290,3,NULL,0,_binary '\0',_binary '\0',285,9),(292,4,NULL,0,_binary '\0',_binary '\0',285,13),(401,1,NULL,0,_binary '\0',_binary '\0',400,6),(403,2,NULL,0,_binary '\0',_binary '\0',400,7);
/*!40000 ALTER TABLE `user_gameinfo` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-08-21 10:08:23
