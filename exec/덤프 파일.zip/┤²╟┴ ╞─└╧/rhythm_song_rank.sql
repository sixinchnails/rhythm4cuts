-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: i9b109.p.ssafy.io    Database: rhythm
-- ------------------------------------------------------
-- Server version	8.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `song_rank`
--

DROP TABLE IF EXISTS `song_rank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `song_rank` (
  `song_rank_seq` bigint NOT NULL,
  `ranking` int NOT NULL,
  `singer` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`song_rank_seq`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `song_rank`
--

LOCK TABLES `song_rank` WRITE;
/*!40000 ALTER TABLE `song_rank` DISABLE KEYS */;
INSERT INTO `song_rank` VALUES (505,1,'정국','Seven (feat. Latto) - Clean Ver.'),(506,2,'NewJeans','Super Shy'),(507,3,'NewJeans','ETA'),(508,4,'박재정','헤어지자 말해요'),(509,5,'(여자)아이들','퀸카 (Queencard)'),(510,6,'IVE (아이브)','I AM'),(511,7,'Lauv','Steal The Show (From “엘리멘탈”)'),(512,8,'우디 (Woody)','사막에서 꽃을 피우듯'),(513,9,'aespa','Spicy'),(514,10,'임영웅','모래 알갱이'),(515,11,'NewJeans','New Jeans'),(516,12,'LE SSERAFIM (르세라핌)','이브, 프시케 그리고 푸른 수염의 아내'),(517,13,'임영웅','사랑은 늘 도망가'),(518,14,'전소미','Fast Forward'),(519,15,'NewJeans','Hype boy'),(520,16,'임영웅','우리들의 블루스'),(521,17,'정국','Still With You'),(522,18,'Paul Blanco','Summer (Feat. BE’O (비오))'),(523,19,'임영웅','다시 만날 수 있을까'),(524,20,'IVE (아이브)','Kitsch'),(525,21,'임영웅','무지개'),(526,22,'임영웅','이제 나만 믿어요'),(527,23,'LE SSERAFIM (르세라핌)','UNFORGIVEN (feat. Nile Rodgers)'),(528,24,'NewJeans','Ditto'),(529,25,'임영웅','London Boy'),(530,26,'임영웅','아버지'),(531,27,'임영웅','Polaroid'),(532,28,'임영웅','인생찬가'),(533,29,'NewJeans','Cool With You'),(534,30,'임영웅','A bientot'),(535,31,'이세계아이돌','KIDDING'),(536,32,'임영웅','손이 참 곱던 그대'),(537,33,'임영웅','사랑해 진짜'),(538,34,'임영웅','연애편지'),(539,35,'NewJeans','Attention'),(540,36,'임영웅','보금자리'),(541,37,'NewJeans','OMG'),(542,38,'V','Love Me Again'),(543,39,'방탄소년단','Dynamite'),(544,40,'세븐틴 (SEVENTEEN)','손오공'),(545,41,'윤하 (YOUNHA)','사건의 지평선'),(546,42,'ITZY (있지)','CAKE'),(547,43,'IVE (아이브)','After LIKE'),(548,44,'STAYC(스테이씨)','Bubble'),(549,45,'방탄소년단','Take Two'),(550,46,'IVE (아이브)','LOVE DIVE'),(551,47,'Charlie Puth','I Don\'t Think That I Like Her'),(552,48,'NCT DREAM','ISTJ'),(553,49,'지수 (JISOO)','꽃'),(554,50,'방탄소년단','봄날'),(555,51,'우효','민들레 (single ver.)'),(556,52,'DK(디셈버)','심(心)'),(557,53,'STAYC(스테이씨)','Teddy Bear'),(558,54,'Charlie Puth','Dangerously'),(559,55,'임한별','사랑하지 않아서 그랬어'),(560,56,'탑현','나에게 그대만이'),(561,57,'김연지','미친 사랑의 노래'),(562,58,'DK(디셈버)','파이팅 해야지 (Feat. 이영지)'),(563,59,'부석순 (SEVENTEEN)','Like Crazy'),(564,60,'지민','잠깐 시간 될까'),(565,61,'이무진','Dreamers [Music from the FIFA World Cup Qatar 2022 Official Soundtrack] (Feat. FIFA Sound)'),(566,62,'정국','ASAP'),(567,63,'방탄소년단','여름이 들려 (Summer Comes)'),(568,64,'NewJeans','사람 Pt.2 (feat. 아이유)'),(569,65,'오마이걸 (OH MY GIRL)','Candy'),(570,66,'Agust D','Butter'),(571,67,'NCT DREAM','너의 모든 순간'),(572,68,'방탄소년단','Rainy Days'),(573,69,'성시경','LOCKDOWN'),(574,70,'V','사랑인가 봐'),(575,71,'이세계아이돌','Cupid'),(576,72,'멜로망스','건물 사이에 피어난 장미 (Rose Blossom)'),(577,73,'FIFTY FIFTY','첫 키스에 내 심장은 120BPM'),(578,74,'H1-KEY (하이키)','물론'),(579,75,'경서','ANTIFRAGILE'),(580,76,'허각','사실말야내가말야그게그러니까말이야'),(581,77,'LE SSERAFIM (르세라핌)','In Bloom'),(582,78,'케이시 (Kassy)','Yogurt Shake'),(583,79,'ZEROBASEONE (제로베이스원)','Allergy'),(584,80,'NCT DREAM','사랑..그게 뭔데'),(585,81,'(여자)아이들','I WANT'),(586,82,'지아','Another World'),(587,83,'IVE (아이브)','Permission to Dance'),(588,84,'이세계아이돌','on the street (with J. Cole)'),(589,85,'방탄소년단','그중에 그대를 만나'),(590,86,'j-hope','사랑의 바보'),(591,87,'J. Cole','Broken Melodies'),(592,88,'김호중','STAY'),(593,89,'제이세라','다정히 내 이름을 부르면'),(594,90,'NCT DREAM','취중고백'),(595,91,'The Kid LAROI','해요 (2022)'),(596,92,'Justin Bieber','RE : WIND'),(597,93,'경서예지','잘 지내자, 우리 (여름날 우리 X 로이킴)'),(598,94,'전건호','TOMBOY'),(599,95,'김민석 (멜로망스)','That\'s Hilarious'),(600,96,'#안녕','That’s Not How This Works (feat. Dan + Shay)'),(601,97,'이세계아이돌','Heaven(2023)'),(602,98,'로이킴','빛이 나는 너에게'),(603,99,'(여자)아이들','겨울봄'),(604,100,'Charlie Puth','당신을 만나');
/*!40000 ALTER TABLE `song_rank` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-08-21 10:08:25
