-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: i9b109.p.ssafy.io    Database: rhythm
-- ------------------------------------------------------
-- Server version	8.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `game_image`
--

DROP TABLE IF EXISTS `game_image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_image` (
  `image_seq` int NOT NULL,
  `common_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `create_date` datetime(6) DEFAULT NULL,
  `download_date` datetime(6) DEFAULT NULL,
  `download_status` bit(1) DEFAULT NULL,
  `file_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `game_rank` int DEFAULT NULL,
  `private_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_file_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `background_seq` int DEFAULT NULL,
  `game_seq` int DEFAULT NULL,
  `user_seq` int DEFAULT NULL,
  PRIMARY KEY (`image_seq`),
  KEY `FKsnxrlo5s31a0xdo7jah8x5o0l` (`background_seq`),
  KEY `FKekqd5h5tnjpgotkd0tgr3wrd0` (`game_seq`),
  KEY `FK3jt5aq4uccn2gs7io6jjq37ap` (`user_seq`),
  CONSTRAINT `FK3jt5aq4uccn2gs7io6jjq37ap` FOREIGN KEY (`user_seq`) REFERENCES `user` (`user_seq`),
  CONSTRAINT `FKekqd5h5tnjpgotkd0tgr3wrd0` FOREIGN KEY (`game_seq`) REFERENCES `game_info` (`game_seq`),
  CONSTRAINT `FKsnxrlo5s31a0xdo7jah8x5o0l` FOREIGN KEY (`background_seq`) REFERENCES `background` (`background_seq`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_image`
--

LOCK TABLES `game_image` WRITE;
/*!40000 ALTER TABLE `game_image` DISABLE KEYS */;
INSERT INTO `game_image` VALUES (120,'https://rhythm4cuts.s3.ap-northeast-2.amazonaws.com/img/012382fa1597e60cffef3c58c5212e7f.jpg','2023-08-18 00:08:00.695540',NULL,_binary '\0',NULL,NULL,'https://rhythm4cuts.s3.ap-northeast-2.amazonaws.com/img/012382fa1597e60cffef3c58c5212e7f.jpg',NULL,NULL,NULL,NULL,6),(121,'https://rhythm4cuts.s3.ap-northeast-2.amazonaws.com/img/aa58e437-05db-4183-9d4d-7ec40a008d88.jpg','2023-08-18 00:08:00.740068',NULL,_binary '\0',NULL,NULL,'https://rhythm4cuts.s3.ap-northeast-2.amazonaws.com/img/aa58e437-05db-4183-9d4d-7ec40a008d88.jpg',NULL,NULL,NULL,NULL,6),(122,'https://rhythm4cuts.s3.ap-northeast-2.amazonaws.com/img/D8R-NuUVsAAxTic.jpg','2023-08-18 00:08:00.766540',NULL,_binary '\0',NULL,NULL,'https://rhythm4cuts.s3.ap-northeast-2.amazonaws.com/img/D8R-NuUVsAAxTic.jpg',NULL,NULL,NULL,NULL,6),(132,NULL,'2023-08-18 00:19:23.625912',NULL,_binary '\0','202308180019232iFDHhKq.jpg',2,'https://s3.ap-northeast-2.amazonaws.com/rhythm4cuts/img/202308180019232iFDHhKq.jpg',NULL,NULL,NULL,123,8),(133,NULL,'2023-08-18 00:19:27.878695',NULL,_binary '\0','20230818001927DCqsUid9.jpg',3,'https://s3.ap-northeast-2.amazonaws.com/rhythm4cuts/img/20230818001927DCqsUid9.jpg',NULL,NULL,NULL,123,6),(134,NULL,'2023-08-18 00:19:31.096623',NULL,_binary '\0','20230818001930ZjUplvCN.jpg',1,'https://s3.ap-northeast-2.amazonaws.com/rhythm4cuts/img/20230818001930ZjUplvCN.jpg',NULL,NULL,NULL,123,10),(144,NULL,'2023-08-18 00:31:56.028692',NULL,_binary '\0','20230818003155nZeN8CrC.jpg',3,'https://s3.ap-northeast-2.amazonaws.com/rhythm4cuts/img/20230818003155nZeN8CrC.jpg',NULL,NULL,NULL,135,8),(145,NULL,'2023-08-18 00:31:59.377469',NULL,_binary '\0','20230818003159j7LqvhTE.jpg',1,'https://s3.ap-northeast-2.amazonaws.com/rhythm4cuts/img/20230818003159j7LqvhTE.jpg',NULL,NULL,NULL,135,10),(146,NULL,'2023-08-18 00:32:02.481972',NULL,_binary '\0','20230818003202CnsrDi4Z.jpg',4,'https://s3.ap-northeast-2.amazonaws.com/rhythm4cuts/img/20230818003202CnsrDi4Z.jpg',NULL,NULL,NULL,135,7),(147,NULL,'2023-08-18 00:32:04.880907',NULL,_binary '\0','20230818003204IzOFty9G.jpg',2,'https://s3.ap-northeast-2.amazonaws.com/rhythm4cuts/img/20230818003204IzOFty9G.jpg',NULL,NULL,NULL,135,6),(215,NULL,'2023-08-18 03:05:39.199267',NULL,_binary '\0','20230818030539gfksdX2L.jpg',1,'https://s3.ap-northeast-2.amazonaws.com/rhythm4cuts/img/20230818030539gfksdX2L.jpg',NULL,NULL,NULL,206,6),(216,NULL,'2023-08-18 03:05:42.594916',NULL,_binary '\0','20230818030542ytFBFCEq.jpg',4,'https://s3.ap-northeast-2.amazonaws.com/rhythm4cuts/img/20230818030542ytFBFCEq.jpg',NULL,NULL,NULL,206,9),(217,NULL,'2023-08-18 03:05:52.841755',NULL,_binary '\0','20230818030552aXoOLUiF.jpg',2,'https://s3.ap-northeast-2.amazonaws.com/rhythm4cuts/img/20230818030552aXoOLUiF.jpg',NULL,NULL,NULL,206,8),(218,NULL,'2023-08-18 03:05:57.808169',NULL,_binary '\0','20230818030557rplPECtl.jpg',3,'https://s3.ap-northeast-2.amazonaws.com/rhythm4cuts/img/20230818030557rplPECtl.jpg',NULL,NULL,NULL,206,7),(228,NULL,'2023-08-18 03:12:41.436901',NULL,_binary '\0','20230818031241U8JBjaUP.jpg',1,'https://s3.ap-northeast-2.amazonaws.com/rhythm4cuts/img/20230818031241U8JBjaUP.jpg',NULL,NULL,NULL,219,6),(229,NULL,'2023-08-18 03:13:34.361918',NULL,_binary '\0','202308180313344jHfqz6Z.jpg',4,'https://s3.ap-northeast-2.amazonaws.com/rhythm4cuts/img/202308180313344jHfqz6Z.jpg',NULL,NULL,NULL,219,9),(239,NULL,'2023-08-18 03:19:21.146867',NULL,_binary '\0','20230818031921TJhr2rRI.jpg',3,'https://s3.ap-northeast-2.amazonaws.com/rhythm4cuts/img/20230818031921TJhr2rRI.jpg',NULL,NULL,NULL,230,7),(240,NULL,'2023-08-18 03:19:28.941801',NULL,_binary '\0','20230818031928Kj24pRUm.jpg',2,'https://s3.ap-northeast-2.amazonaws.com/rhythm4cuts/img/20230818031928Kj24pRUm.jpg',NULL,NULL,NULL,230,9),(266,NULL,'2023-08-18 03:49:00.538509',NULL,_binary '\0','20230818034900NyPRWddb.jpg',1,'https://s3.ap-northeast-2.amazonaws.com/rhythm4cuts/img/20230818034900NyPRWddb.jpg',NULL,NULL,NULL,259,6),(267,NULL,'2023-08-18 03:49:06.241227',NULL,_binary '\0','20230818034906V5BqLr9b.jpg',3,'https://s3.ap-northeast-2.amazonaws.com/rhythm4cuts/img/20230818034906V5BqLr9b.jpg',NULL,NULL,NULL,259,9),(268,NULL,'2023-08-18 03:49:08.697299',NULL,_binary '\0','20230818034908h8NRbDom.jpg',2,'https://s3.ap-northeast-2.amazonaws.com/rhythm4cuts/img/20230818034908h8NRbDom.jpg',NULL,NULL,NULL,259,8),(269,NULL,'2023-08-18 03:49:08.958528',NULL,_binary '\0','20230818034908rRe5rsMH.jpg',2,'https://s3.ap-northeast-2.amazonaws.com/rhythm4cuts/img/20230818034908rRe5rsMH.jpg',NULL,NULL,NULL,259,8),(270,NULL,'2023-08-18 03:49:11.553528',NULL,_binary '\0','20230818034911PJGkiyC3.jpg',2,'https://s3.ap-northeast-2.amazonaws.com/rhythm4cuts/img/20230818034911PJGkiyC3.jpg',NULL,NULL,NULL,259,8),(271,NULL,'2023-08-18 03:49:13.162839',NULL,_binary '\0','20230818034913YhJgScst.jpg',2,'https://s3.ap-northeast-2.amazonaws.com/rhythm4cuts/img/20230818034913YhJgScst.jpg',NULL,NULL,NULL,259,8),(272,NULL,'2023-08-18 03:49:13.959054',NULL,_binary '\0','20230818034913lZDuvNHs.jpg',2,'https://s3.ap-northeast-2.amazonaws.com/rhythm4cuts/img/20230818034913lZDuvNHs.jpg',NULL,NULL,NULL,259,8),(273,NULL,'2023-08-18 03:49:14.898464',NULL,_binary '\0','20230818034914odGZfZ3g.jpg',2,'https://s3.ap-northeast-2.amazonaws.com/rhythm4cuts/img/20230818034914odGZfZ3g.jpg',NULL,NULL,NULL,259,8),(274,NULL,'2023-08-18 03:49:17.732281',NULL,_binary '\0','20230818034917uNo8Qclj.jpg',2,'https://s3.ap-northeast-2.amazonaws.com/rhythm4cuts/img/20230818034917uNo8Qclj.jpg',NULL,NULL,NULL,259,8),(275,NULL,'2023-08-18 03:49:18.548536',NULL,_binary '\0','20230818034918Il6XeDly.jpg',2,'https://s3.ap-northeast-2.amazonaws.com/rhythm4cuts/img/20230818034918Il6XeDly.jpg',NULL,NULL,NULL,259,8),(276,NULL,'2023-08-18 03:49:19.747835',NULL,_binary '\0','202308180349194ySZOVlB.jpg',2,'https://s3.ap-northeast-2.amazonaws.com/rhythm4cuts/img/202308180349194ySZOVlB.jpg',NULL,NULL,NULL,259,8),(277,NULL,'2023-08-18 03:49:20.530318',NULL,_binary '\0','20230818034920GRnFS5sb.jpg',2,'https://s3.ap-northeast-2.amazonaws.com/rhythm4cuts/img/20230818034920GRnFS5sb.jpg',NULL,NULL,NULL,259,8),(278,NULL,'2023-08-18 03:49:21.367568',NULL,_binary '\0','20230818034921ZRsuFzeF.jpg',2,'https://s3.ap-northeast-2.amazonaws.com/rhythm4cuts/img/20230818034921ZRsuFzeF.jpg',NULL,NULL,NULL,259,8),(279,NULL,'2023-08-18 03:49:24.030937',NULL,_binary '\0','20230818034923DtNWj2CQ.jpg',2,'https://s3.ap-northeast-2.amazonaws.com/rhythm4cuts/img/20230818034923DtNWj2CQ.jpg',NULL,NULL,NULL,259,8),(294,NULL,'2023-08-18 08:29:01.649866',NULL,_binary '\0','2023081808290178LiS0t5.jpg',2,'https://s3.ap-northeast-2.amazonaws.com/rhythm4cuts/img/2023081808290178LiS0t5.jpg',NULL,NULL,NULL,285,12),(295,NULL,'2023-08-18 08:29:03.493612',NULL,_binary '\0','20230818082903v7byKRob.jpg',3,'https://s3.ap-northeast-2.amazonaws.com/rhythm4cuts/img/20230818082903v7byKRob.jpg',NULL,NULL,NULL,285,9),(296,NULL,'2023-08-18 08:29:09.287962',NULL,_binary '\0','20230818082909WvOuuRue.jpg',1,'https://s3.ap-northeast-2.amazonaws.com/rhythm4cuts/img/20230818082909WvOuuRue.jpg',NULL,NULL,NULL,285,6),(297,NULL,'2023-08-18 08:29:12.858738',NULL,_binary '\0','20230818082912WFc7qpBI.jpg',4,'https://s3.ap-northeast-2.amazonaws.com/rhythm4cuts/img/20230818082912WFc7qpBI.jpg',NULL,NULL,NULL,285,13);
/*!40000 ALTER TABLE `game_image` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-08-21 10:08:27
