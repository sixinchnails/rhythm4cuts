-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: i9b109.p.ssafy.io    Database: rhythm
-- ------------------------------------------------------
-- Server version	8.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `request_friend`
--

DROP TABLE IF EXISTS `request_friend`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `request_friend` (
  `request_seq` bigint NOT NULL,
  `request_date` datetime(6) DEFAULT NULL,
  `request_status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `from_user` int DEFAULT NULL,
  `to_user` int DEFAULT NULL,
  PRIMARY KEY (`request_seq`),
  KEY `FKox7r3udfhwci6drlfap0ql5xn` (`from_user`),
  KEY `FKt2svgmss3d8ensqq8ecvio73q` (`to_user`),
  CONSTRAINT `FKox7r3udfhwci6drlfap0ql5xn` FOREIGN KEY (`from_user`) REFERENCES `user` (`user_seq`),
  CONSTRAINT `FKt2svgmss3d8ensqq8ecvio73q` FOREIGN KEY (`to_user`) REFERENCES `user` (`user_seq`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `request_friend`
--

LOCK TABLES `request_friend` WRITE;
/*!40000 ALTER TABLE `request_friend` DISABLE KEYS */;
INSERT INTO `request_friend` VALUES (151,'2023-08-18 00:43:05.449982','CONNECTED',10,6),(154,'2023-08-18 00:44:06.067299','WAIT',10,8),(155,'2023-08-18 00:44:43.453474','CONNECTED',8,10),(241,'2023-08-18 03:21:03.839327','WAIT',12,9),(242,'2023-08-18 03:21:10.690316','CONNECTED',12,8),(252,'2023-08-18 03:43:02.186730','CONNECTED',6,8),(255,'2023-08-18 03:43:26.635365','WAIT',6,7),(256,'2023-08-18 03:43:33.506260','CONNECTED',6,9);
/*!40000 ALTER TABLE `request_friend` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-08-21 10:08:22
