package com.b109.rhythm4cuts.model.domain;


public enum RequestStatus {
    WAIT, REJECTED, CONNECTED
}
