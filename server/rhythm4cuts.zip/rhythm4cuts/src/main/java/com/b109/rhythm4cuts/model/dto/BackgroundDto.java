package com.b109.rhythm4cuts.model.dto;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class BackgroundDto {

    private int backgroundSeq;
    private String backgroundName;
    private String fileName;
}
