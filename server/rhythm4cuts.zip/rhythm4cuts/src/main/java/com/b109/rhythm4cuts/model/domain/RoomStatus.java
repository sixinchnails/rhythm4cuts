package com.b109.rhythm4cuts.model.domain;

public enum RoomStatus {
    WAIT, RUN, END
}
