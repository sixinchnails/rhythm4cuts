package com.b109.rhythm4cuts.controller;

import com.b109.rhythm4cuts.model.dto.FriendDto;
import lombok.RequiredArgsConstructor;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Controller;

@Controller
@RequiredArgsConstructor
public class StompController {
    private final SimpMessagingTemplate messagingTemplate;

//    @CrossOrigin(origins = "http://localhost:8080")
    @MessageMapping(value = "/request")
    public void reqeustFriend(FriendDto friendDto) {
        System.out.println("요청 옴");
        friendDto.setMessage(friendDto.getToUser() + "님이 " + friendDto.getToUser() + "님에게 요청을 보냈습니다.");
        System.out.println("/subscribe/friend/" + friendDto.getToUser());
        messagingTemplate.convertAndSend("/subscribe/friend/" + friendDto.getToUser(), friendDto);
    }
}
