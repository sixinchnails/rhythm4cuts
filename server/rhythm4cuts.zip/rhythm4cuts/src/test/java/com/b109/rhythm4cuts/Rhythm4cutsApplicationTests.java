package com.b109.rhythm4cuts;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Rhythm4cutsApplicationTests {

	@Test
	void contextLoads() {
	}

}
